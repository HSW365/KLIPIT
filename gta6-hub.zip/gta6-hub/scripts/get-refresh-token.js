// One-time LOCAL run on your Windows PC to mint YT_REFRESH_TOKEN.
// Usage: set YT_CLIENT_ID and YT_CLIENT_SECRET env vars, then: node scripts/get-refresh-token.js
const http = require("http");
const { google } = require("googleapis");

const { YT_CLIENT_ID, YT_CLIENT_SECRET } = process.env;
if (!YT_CLIENT_ID || !YT_CLIENT_SECRET) {
  console.error("Set YT_CLIENT_ID and YT_CLIENT_SECRET first.");
  process.exit(1);
}

const REDIRECT = "http://localhost:3000/callback";
const oauth2 = new google.auth.OAuth2(YT_CLIENT_ID, YT_CLIENT_SECRET, REDIRECT);

const url = oauth2.generateAuthUrl({
  access_type: "offline",
  prompt: "consent",
  scope: ["https://www.googleapis.com/auth/youtube.upload"],
});

const server = http.createServer(async (req, res) => {
  if (!req.url.startsWith("/callback")) { res.end("waiting..."); return; }
  const code = new URL(req.url, REDIRECT).searchParams.get("code");
  try {
    const { tokens } = await oauth2.getToken(code);
    res.end("Done. Refresh token printed in your terminal. You can close this tab.");
    console.log("\n=== YT_REFRESH_TOKEN ===\n" + tokens.refresh_token + "\n========================\n");
    console.log("Save that as a GitHub secret named YT_REFRESH_TOKEN.");
  } catch (e) {
    res.end("Error: " + e.message);
    console.error(e);
  } finally {
    setTimeout(() => server.close(), 500);
  }
});

server.listen(3000, async () => {
  console.log("Opening browser for Google consent...");
  const open = (await import("open")).default;
  await open(url);
  console.log("If it didn't open, paste this URL:\n" + url);
});

// Stage 02 — ElevenLabs voiceover from output/script.txt -> output/voiceover.mp3
const fs = require("fs");
const path = require("path");

const API_KEY = process.env.ELEVENLABS_API_KEY;
const VOICE_ID = process.env.ELEVENLABS_VOICE_ID;
const OUT = path.join(__dirname, "..", "output");

async function main() {
  if (!API_KEY) throw new Error("ELEVENLABS_API_KEY is not set");
  if (!VOICE_ID) throw new Error("ELEVENLABS_VOICE_ID is not set");

  const scriptPath = path.join(OUT, "script.txt");
  if (!fs.existsSync(scriptPath)) throw new Error("output/script.txt missing — run stage 01 first");
  const text = fs.readFileSync(scriptPath, "utf8").trim();
  if (text.length < 40) throw new Error("script.txt too short to voice");

  const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${VOICE_ID}`, {
    method: "POST",
    headers: {
      "xi-api-key": API_KEY,
      "Content-Type": "application/json",
      Accept: "audio/mpeg",
    },
    body: JSON.stringify({
      text,
      model_id: "eleven_multilingual_v2",
      voice_settings: { stability: 0.4, similarity_boost: 0.8 },
    }),
  });

  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    throw new Error(`ElevenLabs error ${res.status}: ${detail.slice(0, 300)}`);
  }

  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length < 1000) throw new Error("voiceover response too small — likely failed");
  fs.mkdirSync(OUT, { recursive: true });
  fs.writeFileSync(path.join(OUT, "voiceover.mp3"), buf);
  console.log(`[02] voiceover.mp3 written (${buf.length} bytes)`);
}

main().catch((e) => { console.error("[02] FAILED:", e.message); process.exit(1); });

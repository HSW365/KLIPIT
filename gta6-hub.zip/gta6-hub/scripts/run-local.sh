#!/usr/bin/env bash
# Local test runner — builds today's video WITHOUT uploading, so you can preview output/final.mp4.
set -euo pipefail
cd "$(dirname "$0")/.."

echo "=== [local] Stage 01: script ==="
node scripts/01-generate-script.js
echo "=== [local] Stage 02: voiceover ==="
node scripts/02-generate-voiceover.js
echo "=== [local] Stage 03: visuals ==="
node scripts/03-generate-visuals.js
echo "=== [local] Stage 04: assemble ==="
bash scripts/04-assemble-video.sh

echo ""
echo "DONE. Preview: output/final.mp4  (nothing was uploaded)"

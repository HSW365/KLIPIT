#!/usr/bin/env bash
# Stage 04 — ffmpeg Ken Burns slideshow + voiceover -> output/final.mp4
set -euo pipefail

OUT="$(cd "$(dirname "$0")/.." && pwd)/output"
VOICE="$OUT/voiceover.mp3"

[ -f "$VOICE" ] || { echo "[04] FAILED: voiceover.mp3 missing"; exit 1; }
for i in 0 1 2 3; do
  [ -f "$OUT/bg_$i.jpg" ] || { echo "[04] FAILED: bg_$i.jpg missing"; exit 1; }
done

# total audio duration (seconds, rounded up)
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$VOICE")
DUR=${DUR%.*}
[ "$DUR" -gt 0 ] || DUR=60
PER=$(( (DUR + 3) / 4 ))   # seconds per image, covers full audio
[ "$PER" -lt 3 ] && PER=3
FRAMES=$(( PER * 25 ))

echo "[04] audio ${DUR}s -> ${PER}s/image, ${FRAMES} frames each"

# Build a Ken Burns clip per image
for i in 0 1 2 3; do
  ffmpeg -y -loop 1 -i "$OUT/bg_$i.jpg" \
    -vf "scale=2400:-1,zoompan=z='min(zoom+0.0008,1.15)':d=${FRAMES}:s=1920x1080:fps=25,format=yuv420p" \
    -t "$PER" -c:v libx264 -preset medium -pix_fmt yuv420p "$OUT/clip_$i.mp4"
done

# Concat clips
cat > "$OUT/clips.txt" << LIST
file 'clip_0.mp4'
file 'clip_1.mp4'
file 'clip_2.mp4'
file 'clip_3.mp4'
LIST

ffmpeg -y -f concat -safe 0 -i "$OUT/clips.txt" -c copy "$OUT/slideshow.mp4"

# Mux voiceover, cut to shortest (audio ends the video)
ffmpeg -y -i "$OUT/slideshow.mp4" -i "$VOICE" \
  -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -shortest "$OUT/final.mp4"

echo "[04] final.mp4 written"

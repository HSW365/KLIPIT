// 01-generate-script.js
// Pulls fresh GTA6 news, then asks Claude to write a daily video script.
// Env vars: SERPAPI_KEY, ANTHROPIC_API_KEY
// Optional: ANTHROPIC_MODEL (defaults to claude-sonnet-5)

const fs = require("fs");

const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-5";

async function getNews() {
  if (!process.env.SERPAPI_KEY) {
    console.warn("No SERPAPI_KEY set — falling back to general GTA6 talking points.");
    return "No live headlines available — cover the latest known GTA6 rumors, trailer talk, and release-window speculation.";
  }
  const url =
    "https://serpapi.com/search.json?q=" +
    encodeURIComponent("GTA 6 news") +
    "&tbm=nws&api_key=" +
    process.env.SERPAPI_KEY;

  const res = await fetch(url);
  if (!res.ok) {
    console.warn(`SerpAPI ${res.status} — falling back to general talking points.`);
    return "No live headlines available — cover the latest known GTA6 rumors and release-window speculation.";
  }
  const data = await res.json();
  const items = (data.news_results || [])
    .slice(0, 8)
    .map((n) => `- ${n.title}: ${n.snippet || ""}`);
  return items.join("\n") || "No fresh headlines today — cover general GTA6 speculation and rumors.";
}

async function writeScript(newsBlock) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 1500,
      messages: [
        {
          role: "user",
          content: `You write daily YouTube scripts for a GTA6 news/commentary channel called Hoodstar365.
Tone: hype, energetic, insider-feel, but ACCURATE to the news given — never state rumors as confirmed fact.
This is commentary/news, not affiliated with Rockstar Games. Do not claim to show game footage.

Today's headlines/rumors:
${newsBlock}

Write a 60-90 second spoken script (just the words to be read aloud — no stage directions, no camera notes).
Open with a strong hook in the first line. Close with a subscribe call-to-action for @Hoodstar365.
Also output a YouTube title (under 70 chars) and a description (3-4 sentences + 5 hashtags).
Respond EXACTLY in this format and nothing else:
TITLE: ...
DESCRIPTION: ...
SCRIPT: ...`,
        },
      ],
    }),
  });

  const data = await res.json();
  if (data.error) {
    throw new Error(`Anthropic API error: ${data.error.type} — ${data.error.message}`);
  }
  if (!Array.isArray(data.content)) {
    throw new Error("Unexpected Anthropic response: " + JSON.stringify(data).slice(0, 500));
  }
  return data.content
    .filter((b) => b.type === "text")
    .map((b) => b.text)
    .join("\n");
}

(async () => {
  const news = await getNews();
  const output = await writeScript(news);

  const title = output.match(/TITLE:\s*(.+)/)?.[1]?.trim() || "GTA6 Daily Update";
  const description =
    output.match(/DESCRIPTION:\s*([\s\S]*?)SCRIPT:/)?.[1]?.trim() ||
    "Daily GTA6 news & commentary. Not affiliated with Rockstar Games. #GTA6 #GTAVI #GTA6News #Gaming #Hoodstar365";
  const script = output.match(/SCRIPT:\s*([\s\S]*)/)?.[1]?.trim() || output;

  if (!script || script.length < 40) {
    throw new Error("Script came back empty/too short — aborting so we don't post a blank video.");
  }

  fs.mkdirSync("./output", { recursive: true });
  fs.writeFileSync("./output/title.txt", title);
  fs.writeFileSync("./output/description.txt", description);
  fs.writeFileSync("./output/script.txt", script);

  console.log("Generated title:", title);
  console.log("Script length:", script.length, "chars");
})().catch((err) => {
  console.error("01-generate-script failed:", err.message);
  process.exit(1);
});

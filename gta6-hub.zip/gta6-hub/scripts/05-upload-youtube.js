// Stage 05 — upload output/final.mp4 to YouTube via Data API v3
const fs = require("fs");
const path = require("path");
const { google } = require("googleapis");

const OUT = path.join(__dirname, "..", "output");

async function main() {
  const { YT_CLIENT_ID, YT_CLIENT_SECRET, YT_REFRESH_TOKEN } = process.env;
  if (!YT_CLIENT_ID || !YT_CLIENT_SECRET || !YT_REFRESH_TOKEN)
    throw new Error("YT_CLIENT_ID / YT_CLIENT_SECRET / YT_REFRESH_TOKEN must be set");

  const video = path.join(OUT, "final.mp4");
  if (!fs.existsSync(video)) throw new Error("output/final.mp4 missing — run stage 04 first");

  const title = fs.existsSync(path.join(OUT, "title.txt"))
    ? fs.readFileSync(path.join(OUT, "title.txt"), "utf8").trim().slice(0, 100)
    : "GTA6 News Update";
  const description = fs.existsSync(path.join(OUT, "description.txt"))
    ? fs.readFileSync(path.join(OUT, "description.txt"), "utf8").trim()
    : "Daily GTA 6 news & commentary.";

  const oauth2 = new google.auth.OAuth2(YT_CLIENT_ID, YT_CLIENT_SECRET, "http://localhost");
  oauth2.setCredentials({ refresh_token: YT_REFRESH_TOKEN });
  const youtube = google.youtube({ version: "v3", auth: oauth2 });

  const res = await youtube.videos.insert({
    part: ["snippet", "status"],
    requestBody: {
      snippet: {
        title,
        description,
        tags: ["GTA6", "GTA 6", "GTA6 news", "GTA 6 news", "Hoodstar365"],
        categoryId: "20", // Gaming
      },
      status: { privacyStatus: "public", selfDeclaredMadeForKids: false },
    },
    media: { body: fs.createReadStream(video) },
  });

  console.log(`[05] uploaded: https://youtu.be/${res.data.id}`);
}

main().catch((e) => { console.error("[05] FAILED:", e.message); process.exit(1); });

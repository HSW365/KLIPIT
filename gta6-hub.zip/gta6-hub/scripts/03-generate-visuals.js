// Stage 03 — fal.ai Flux: 4 cinematic backgrounds -> output/bg_0..3.jpg
const fs = require("fs");
const path = require("path");

const FAL_KEY = process.env.FAL_KEY;
const OUT = path.join(__dirname, "..", "output");

// Generic cinematic aesthetic — no trademarked place-names or game art.
const PROMPTS = [
  "cinematic wide shot of a neon-soaked tropical city skyline at night, palm trees, glowing pink and teal reflections on wet streets, moody film grain, ultra detailed, 16:9",
  "sleek sports car silhouette speeding down a coastal highway at sunset, orange and purple sky, lens flare, cinematic, dramatic lighting, 16:9",
  "moody neon night street in a tropical metropolis, rain-slicked asphalt, glowing signs, cinematic atmosphere, high detail, 16:9",
  "aerial drone view of a tropical coastline and downtown high-rises at dusk, warm golden light, cinematic color grade, ultra detailed, 16:9",
];

async function genOne(prompt, idx) {
  const res = await fetch("https://fal.run/fal-ai/flux/dev", {
    method: "POST",
    headers: { Authorization: `Key ${FAL_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ prompt, image_size: "landscape_16_9", num_images: 1 }),
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    throw new Error(`fal.ai error ${res.status}: ${detail.slice(0, 300)}`);
  }
  const data = await res.json();
  const url = data?.images?.[0]?.url;
  if (!url) throw new Error(`no image url returned for prompt ${idx}`);
  const img = await fetch(url);
  if (!img.ok) throw new Error(`failed to download image ${idx}: ${img.status}`);
  const buf = Buffer.from(await img.arrayBuffer());
  fs.writeFileSync(path.join(OUT, `bg_${idx}.jpg`), buf);
  console.log(`[03] bg_${idx}.jpg written (${buf.length} bytes)`);
}

async function main() {
  if (!FAL_KEY) throw new Error("FAL_KEY is not set");
  fs.mkdirSync(OUT, { recursive: true });
  for (let i = 0; i < PROMPTS.length; i++) {
    await genOne(PROMPTS[i], i);
  }
  console.log("[03] all 4 backgrounds generated");
}

main().catch((e) => { console.error("[03] FAILED:", e.message); process.exit(1); });
